<img src="{{asset('teckel.jpg')}}" alt="Teckelbild">

